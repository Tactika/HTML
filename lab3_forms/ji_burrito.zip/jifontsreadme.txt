This font is free for personal use only.  Contact me for any information on Commercial use.
All of the artwork is my own, if this font is redistrubuted, please give me credit, and provide a link to my webpage.
Please don't distribute this without this read-me file, or  offer it on a CD for commercial purposes without contacting me first.

Jeri Ingalls

e-mail:  ingalls@kalama.com
http://www.geocities.com/Heartland/Shores/7173
